import sys

from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import Row
from pyspark.sql import SQLContext
from pyspark.sql.functions import coalesce, lit
from pyspark.sql.types import *


glueContext = GlueContext(SparkContext.getOrCreate())
sqlContext = SQLContext(sc)

source_df = sqlContext.read.format('jdbc').options(
    url="jdbc:mysql://cencosud-mariadb-preprod.cindgoz7oqnp.us-east-1.rds.amazonaws.com:3306/JUMBO",
    driver="com.mysql.jdbc.Driver",
    dbtable="PROD_CORR",
    user="root",
    password="cencosud2015").load()

arch = "CL_MOTOR_ENTRADA_JUMBO_VTAS_*.DAT.gz"

df_b = sc.textFile(
    's3n://cencosud.exalitica.com/prod/datos/entrada/jumbo/trx/{}'.format(arch))

schema = StructType([
    StructField("chain_cd", StringType(), True),
    StructField("sales_channel_cd", StringType(), True),
    StructField("location_id", StringType(), True),
    StructField("pos_register_id", StringType(), True),
    StructField("tran_start_dt", StringType(), True),
    StructField("tran_start_tm", StringType(), True),
    StructField("tran_num", StringType(), True),
    StructField("party_id", StringType(), True),
    StructField("promo_id", StringType(), True),
    StructField("item_id", StringType(), True),
    StructField("item_qty_umb", StringType(), True),
    StructField("actual_amt", StringType(), True),
    StructField("item_qty_promo_umb", StringType(), True),
    StructField("discount_amt", StringType(), True),
    StructField("monto_neto", StringType(), True),
    StructField("monto_bruto", StringType(), True),
    StructField("weighted_average_cost_amt", StringType(), True),
    StructField("sales_transaction_type_cd", StringType(), True),
    StructField("marca_tmas", StringType(), True)
])

rowRDD = df_b.map(lambda y: y.split("|"))

r2 = rowRDD.map(lambda x: Row(str(x[0]), str(x[1]), str(x[2]), str(x[3]), str(x[4]), str(x[5]), str(x[6]), str(x[7]), str(
    x[8]), str(x[9]), str(x[10]), str(x[11]), str(x[12]), str(x[13]), str(x[14]), str(x[15]), str(x[16]), str(x[17]), str(x[18])))

df = sqlContext.createDataFrame(r2, schema)

df_a = df.where(
    "tran_start_dt > '2017-08-20' AND tran_start_dt > '2017-09-24'")
df_a.registerTempTable("data")

aux = sqlContext.sql("""
select *, 
from_unixtime(unix_timestamp(tran_start_dt,'yyyy-MM-dd'), 'E') as dia_semana,
from_unixtime(unix_timestamp(tran_start_dt,'yyyy-MM-dd'), 'w') as semana_ano,
from_unixtime(unix_timestamp(tran_start_dt,'yyyy-MM-dd'), 'dd') as fecha_dia,
from_unixtime(unix_timestamp(tran_start_dt,'yyyy-MM-dd'), 'MM') as fecha_mes,
from_unixtime(unix_timestamp(tran_start_dt,'yyyy-MM-dd'), 'Y') as fecha_ano
from data
""")

aux.registerTempTable("a1")

aux2 = sqlContext.sql("""
select * , 
case when dia_semana = 'Sun' THEN 1 END AS aux,
case 
when fecha_dia < 6 OR fecha_dia > 27 THEN 'Fin de mes'
when fecha_dia > 5 AND fecha_dia < 13 THEN 'Semana 1'
when fecha_dia > 12 AND fecha_dia < 19 THEN 'Quincena'
when fecha_dia > 18 AND fecha_dia < 28 THEN 'Semana 3'
END AS PER_MEN
from a1
""")
aux2.registerTempTable("a2")

df3 = aux2.withColumn("aux", coalesce(aux2["aux"], lit("0")))

aux3 = df3.withColumn(
    "nueva_semana", (df3["semana_ano"] - df3["aux"]).cast("integer"))

aux3.registerTempTable("a3")

arr = sqlContext.sql("""
select * , 
case 
when nueva_semana = '0' THEN 52
WHEN nueva_semana != '0' THEN nueva_semana 
END AS nueva_semana1
from a3
""")
arr.registerTempTable("arr")

aux4 = sqlContext.sql("""
select * , CONCAT(fecha_ano, '_', nueva_semana1) as N_KEY
from arr
""")
aux4.registerTempTable("a4")

aux5 = aux4.drop(aux4["semana_ano"]).drop(aux4["aux"])
aux5.registerTempTable("aux5")

aux5.repartition(20).write.mode("append").partitionBy("n_key").parquet(
    "s3n://cencosud.exalitica.com/prepod/jumbo/fuentes/fuente")
