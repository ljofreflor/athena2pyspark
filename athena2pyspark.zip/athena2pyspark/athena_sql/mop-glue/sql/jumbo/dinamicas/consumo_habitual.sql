-- consumo_habitual
WITH contactables as (
  select distinct party_id, mail_cli
  from clientes
),

filtro_item AS (
  SELECT DISTINCT item_id, item_subclass_cd
  FROM item_hash
  WHERE item_subclass_cd > 0
),

fuente_filtrada AS (
  SELECT a.party_id, a.tran_start_dt, a.item_id, b.item_subclass_cd
  FROM fuente as a
  left join filtro_item as b
  on a.item_id = b.item_id
  WHERE CAST(a.party_id AS INTEGER) > 0
    AND CAST(a.MONTO_NETO as double) > 0
    and cast(tran_start_dt AS DATE) > (
      SELECT CAST(DATE_ADD('DAY',-DAY_OF_WEEK(NOW())-90,NOW()) AS DATE) -- parametrizar 1 año paris e easy
    )
),

dinsubclass AS (
  SELECT party_id, item_subclass_cd,
    COUNT(
      DISTINCT (
        year(cast(tran_start_dt as date))*100+week(cast(tran_start_dt as date))
      )
    ) AS visitas
FROM fuente_filtrada
GROUP BY party_id, item_subclass_cd
),

dinpop AS (
  SELECT a.party_id, a.item_subclass_cd, a.visitas / b.visitasprom AS lift_subclase
  FROM dinsubclass as a
  LEFT JOIN (
    SELECT item_subclass_cd, AVG(visitas) AS visitasprom
    FROM dinsubclass
    GROUP BY 1
  ) AS b
  ON a.item_subclass_cd = b.item_subclass_cd
)

select b.party_id, b.mail_cli, a.item_subclass_cd, a.lift_subclase
from  dinpop as a, contactables as b
where a.party_id = cast(b.party_id as varchar)
order by a.party_id, a.lift_subclase desc
