-- consumo_habitual_descontinuado
WITH filtro_item AS (
  SELECT DISTINCT item_id, section_cd
  FROM item_hash
  WHERE section_cd > 0
),

fuente_filtrada AS (
  SELECT a.party_id,
    a.tran_start_dt,
    a.item_id,
    b.section_cd
  FROM fuente as a
  left join filtro_item as b
  on a.item_id = b.item_id
  WHERE CAST(a.party_id AS INTEGER) > 0 AND CAST(a.MONTO_NETO as double) > 0
    and cast(tran_start_dt AS DATE)
      >= (SELECT CAST(DATE_ADD('DAY',-DAY_OF_WEEK(NOW())-120,NOW()) AS DATE))
    and  cast(tran_start_dt AS DATE)
      < (SELECT CAST(DATE_ADD('DAY',-DAY_OF_WEEK(NOW())-30,NOW()) AS DATE))
),

fuente_filtrada_corta as (
  SELECT a.party_id,
    a.tran_start_dt,
    a.item_id,
    b.section_cd
  FROM fuente as a
  left join filtro_item as b
  on a.item_id = b.item_id
  WHERE CAST(a.party_id AS INTEGER) > 0 AND CAST(a.MONTO_NETO as double) > 0
    and cast(tran_start_dt AS DATE)
      >= (SELECT CAST(DATE_ADD('DAY',-DAY_OF_WEEK(NOW())-30,NOW()) AS DATE))
),

dinsectionlargapre AS (
  SELECT distinct party_id,
    section_cd,
    year(cast(tran_start_dt as date))*100+week(cast(tran_start_dt as date)) AS nsem3m
  FROM fuente_filtrada
),

dinsectionlarga AS (
  select party_id,
    section_cd,
    cast(count(nsem3m) as double)/12 as nsem3m
  from dinsectionlargapre
  GROUP BY party_id, section_cd
),

dinsectioncortapre AS (
  SELECT distinct party_id,
    section_cd,
    year(cast(tran_start_dt as date))*100+week(cast(tran_start_dt as date))  AS nsem1m
  FROM fuente_filtrada_corta
),

dinsectioncorta AS (
  select party_id,
    section_cd,
    cast(count(nsem1m) as double)/4 as nsem1m
  from dinsectioncortapre
  GROUP BY party_id, section_cd
),

vars as (
  select b.party_id, b.section_cd, (
      case
        when a.nsem1m is null then b.nsem3m/(b.nsem3m+1)
        else ((a.nsem1m+1)-(b.nsem3m+1))/-(b.nsem3m+1)
      end
    ) as variacion
  from dinsectionlarga as b
  left join dinsectioncorta as a
  on a.party_id = b.party_id and a.section_cd = b.section_cd
  where a.nsem1m is null
),

coal_vars AS (
  SELECT a.party_id,
    a.section_cd,
    a.variacion+b.min_variacion AS variacion
  FROM vars AS a,
  (
    SELECT abs(min(variacion)) AS min_variacion
    FROM vars
  ) AS b
),

prom_vars AS (
  SELECT section_cd,
    abs(avg(variacion)) as prom_variacion
  FROM coal_vars
  GROUP BY  section_cd
),

lift_dchd as (
  select a.party_id, a.section_cd,
    a.variacion/b.prom_variacion as lift_dchd
  from coal_vars as a
  left join prom_vars as b
  on a.section_cd=b.section_cd
)

SELECT * FROM lift_dchd
