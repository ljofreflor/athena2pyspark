-- athena2pyspark: priorizacion
WITH filtered_0 AS
(

select cast(col0 as bigint) as col0,
cast(col1 as integer) as col1,
cast(col2 as integer) as col2,
cast(col3 as integer) as col3,
cast(g_ranking as integer) as g_ranking,
cast(o_ranking as integer) as o_ranking,
cast(c_ranking as integer) as c_ranking
from prepriorizacion
where id_com = '{id_com}'
  -- WHERE col0 = '100000057'
)
-- select * from filtered_0 limit 100 -- 62 037 906
,
top1 AS
(
  SELECT col0, ARRAY [col1, col2] as col
  FROM (SELECT t.col0,
               t.col1,
               t.col2,
               DENSE_RANK() OVER (PARTITION BY col0 ORDER BY g_ranking) AS ranking
        FROM filtered_0 AS t) AS t
  WHERE ranking = 1
)
-- select count(*) from top1 -- 602662 , 9,54 -> 10, 38, 7.07 --> 6.49s --> 22.06 s --> 1.5s
,
filtered_1
AS
(
-- como ya para un party_id ya existe una asignacion celda-promo, las 6 celdas
-- restantes ya no pueden admitir 7 promos por lo que hacemos un top 6 de los pro
-- ductos de las celdas que quedan
SELECT col0,
       col1,
       col2,
       g_ranking,
       c_ranking
FROM (SELECT *,
             DENSE_RANK() OVER (PARTITION BY col0,col2 ORDER BY c_ranking) AS tmp_cranking
      FROM (SELECT a.*
            FROM filtered_0 AS a,
                 top1 AS b
            WHERE a.col0 = b.col0
            AND   (a.col1 <> element_at(b.col,1))
            AND   (a.col2 <> element_at(b.col,2))))
WHERE tmp_cranking <= 6)
-- select count(*) from filtered_1 -- (20 346 559) in 13.3 -> 8.97 --> 5.31
,
top2 AS
(
  SELECT col0, ARRAY [col1, col2] as col
  FROM (SELECT t.col0,
               t.col1,
               t.col2,
               RANK() OVER (PARTITION BY col0 ORDER BY g_ranking) AS ranking
        FROM filtered_1 AS t) AS t
  WHERE ranking = 1
)
-- select count(*) from top2 -- 602662 10.72 -> 32.15
,
filtered_2 AS
(
SELECT col0,
       col1,
       col2,
       g_ranking,
       c_ranking
FROM (SELECT *,
             DENSE_RANK() OVER (PARTITION BY col0,col2 ORDER BY c_ranking) AS tmp_cranking
      FROM (SELECT a.*
            FROM filtered_1 AS a,
                 top2 AS b
            WHERE a.col0 = b.col0
            AND   (a.col1 <> element_at(b.col,1))
            AND   (a.col2 <> element_at(b.col,2))))
WHERE tmp_cranking <= 5)

-- select count(*) from  filtered_2 -- (14 355 116) in 16.78 -> 16.06s -> 36.11 -> 6.26
,
top3 AS
(
  SELECT col0, ARRAY [col1, col2] as col
  FROM (SELECT t.col0,
               t.col1,
               t.col2,
               RANK() OVER (PARTITION BY col0 ORDER BY g_ranking) AS ranking
        FROM filtered_2 AS t) AS t
  WHERE ranking = 1
)
-- select count(*) from top3                -- 602662
,
filtered_3 AS
(
SELECT col0,
       col1,
       col2,
       g_ranking,
       c_ranking
FROM (SELECT *,
             DENSE_RANK() OVER (PARTITION BY col0,col2 ORDER BY c_ranking) AS tmp_cranking
      FROM (SELECT a.*
            FROM filtered_2 AS a,
                 top3 AS b
            WHERE a.col0 = b.col0
            AND   (a.col1 <> element_at(b.col,1))
            AND   (a.col2 <> element_at(b.col,2))))
WHERE tmp_cranking <= 4)
-- select count(*) from filtered_3 -- (9 414 909) in 23.44 -> 23.98 -> 56.64 -> 7.76
,
top4 AS
(
  SELECT col0, ARRAY [col1, col2] as col
  FROM (SELECT t.col0,
               t.col1,
               t.col2,
               DENSE_RANK() OVER (PARTITION BY col0 ORDER BY g_ranking) AS ranking
        FROM filtered_3 AS t) AS t
  WHERE ranking = 1
)
-- select count(*) from top4 -- 602662
,
filtered_4 AS
(
SELECT col0,
       col1,
       col2,
       g_ranking,
       c_ranking
FROM (SELECT *,
             DENSE_RANK() OVER (PARTITION BY col0,col2 ORDER BY c_ranking) AS tmp_cranking
      FROM (SELECT a.*
            FROM filtered_3 AS a,
                 top4 AS b
            WHERE a.col0 = b.col0
            AND   (a.col1 <> element_at(b.col,1))
            AND   (a.col2 <> element_at(b.col,2))))
WHERE tmp_cranking <= 3)
-- select count(*) from filtered_4 -- (5 423 958) in 39.19 -> 2m13s -> 13.61
,
top5 AS
(
  SELECT DISTINCT col0,
         FIRST_VALUE(ARRAY[col1,col2]) OVER (PARTITION BY col0 ORDER BY g_ranking ASC) AS col
  FROM filtered_4
)
-- select count(*) from top5 -- 602662
,
filtered_5 AS
(
SELECT col0,
       col1,
       col2,
       g_ranking,
       c_ranking
FROM (SELECT *,
             DENSE_RANK() OVER (PARTITION BY col0,col2 ORDER BY c_ranking) AS tmp_cranking
      FROM (SELECT a.*
            FROM filtered_4 AS a,
                 top5 AS b
            WHERE a.col0 = b.col0
            AND   (a.col1 <> element_at(b.col,1))
            AND   (a.col2 <> element_at(b.col,2))))
WHERE tmp_cranking <= 2)
-- select count(*) from filtered_5 -- (2 410 648) in 1.25 min -> 26.48s
,
top6 AS
(
  SELECT DISTINCT col0,
         FIRST_VALUE(ARRAY[col1,col2]) OVER (PARTITION BY col0 ORDER BY g_ranking ASC) AS col
  FROM filtered_5
)
-- select count(*) from top6 -- 602662
,
filtered_6 AS
(
SELECT col0,
       col1,
       col2,
       g_ranking,
       c_ranking
FROM (SELECT *,
             DENSE_RANK() OVER (PARTITION BY col0,col2 ORDER BY c_ranking) AS tmp_cranking
      FROM (SELECT a.*
            FROM filtered_5 AS a,
                 top6 AS b
            WHERE a.col0 = b.col0
            AND   (a.col1 <> element_at(b.col,1))
            AND   (a.col2 <> element_at(b.col,2))))
WHERE tmp_cranking <= 1)
-- select count(*) from filtered_6 -- 602 662 in 2m 36s -> 48.91s
,
top7 AS
(
  SELECT DISTINCT col0,
         FIRST_VALUE(ARRAY[col1,col2]) OVER (PARTITION BY col0 ORDER BY g_ranking ASC) AS col
  FROM filtered_6
)
-- select count(*) from top7 -- 2m 39s
, priorizacion as (
SELECT col0 as party_id, element_at(col,1) as id_celda, element_at(col,2) as id_oferta, {id_com} as id_com FROM top1
UNION ALL
SELECT col0 as party_id, element_at(col,1) as id_celda, element_at(col,2) as id_oferta, {id_com} as id_com FROM top2
UNION ALL
SELECT col0 as party_id, element_at(col,1) as id_celda, element_at(col,2) as id_oferta, {id_com} as id_com FROM top3
UNION ALL
SELECT col0 as party_id, element_at(col,1) as id_celda, element_at(col,2) as id_oferta, {id_com} as id_com FROM top4
UNION ALL
SELECT col0 as party_id, element_at(col,1) as id_celda, element_at(col,2) as id_oferta, {id_com} as id_com FROM top5
UNION ALL
SELECT col0 as party_id, element_at(col,1) as id_celda, element_at(col,2) as id_oferta, {id_com} as id_com FROM top6
UNION ALL
SELECT col0 as party_id, element_at(col,1) as id_celda, element_at(col,2) as id_oferta, {id_com} as id_com FROM top7
)
select * from priorizacion
