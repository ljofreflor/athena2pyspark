WITH fuente_obj AS (
  with items_filtrado AS (
    SELECT DISTINCT item_id, item_subclass_cd, item_class_cd, brand_cd
    FROM item_hash
  )

  SELECT a.party_id, b.item_subclass_cd, b.item_class_cd, b.brand_cd,
    cast(a.monto_neto as double) as monto,
    case
    when cast(a.monto_neto as double) - cast(a.WEIGHTED_AVERAGE_COST_AMT as double) <0 then 0
    else cast(a.monto_neto as double) - cast(a.WEIGHTED_AVERAGE_COST_AMT as double)
    end as margen
  FROM fuente as a
  join items_filtrado as b
  on a.item_id = b.item_id
  where cast(a.party_id as integer) > 0
    and cast(a.monto_neto as double)>0
    and cast(a.WEIGHTED_AVERAGE_COST_AMT as double)>0
    and b.item_id is not null
),

metricas_item as (
  select item_subclass_cd, brand_cd,
    max(item_class_cd) as item_class_cd,
    sum(monto) as monto_tot,
    sum(margen) as margen_tot,
    count(distinct party_id) as clientes
  from fuente_obj
  group by item_subclass_cd, brand_cd
),

promedios as (
  select a.item_class_cd, avg(a.monto_tot) as monto_prom,
    avg(a.margen_tot) as margen_prom, avg(a.clientes) as clientes_prom
  from metricas_item as a
  group by item_class_cd
)


select a.item_subclass_cd, a.brand_cd, a.item_class_cd,
  a.monto_tot/b.monto_prom as lift_mto, DENSE_RANK() OVER (
    PARTITION BY a.item_class_cd
    ORDER BY a.monto_tot/b.monto_prom desc
  ) AS upsell_mto,
  a.margen_tot/b.margen_prom as lift_margen, DENSE_RANK() OVER (
    PARTITION BY a.item_class_cd
    ORDER BY a.margen_tot/b.margen_prom desc
  ) AS upsell_margen,
  a.clientes/b.clientes_prom as lift_clientes, DENSE_RANK() OVER (
    PARTITION BY a.item_class_cd
    ORDER BY a.clientes/b.clientes_prom desc
  ) AS upsell_clientes
from metricas_item as a
left join promedios as b
on a.item_class_cd = b.item_class_cd
