-- party_rubro
WITH fuente_filtrada AS (
  with items_filtrado AS (
    SELECT DISTINCT item_id, item_class_cd, brand_cd
    FROM item_hash
  )

  SELECT a.party_id, cast(tran_start_dt as date) as tran_start_dt,
    cast(a.monto_neto as double) as monto,
    cast(a.item_qty_umb as double) as unid,
    b.item_id, b.item_class_cd
  FROM fuente as a
  join items_filtrado as b
  on a.item_id = b.item_id
  where cast(a.party_id as integer) > 0 and b.item_id is not null
),

subclasepop AS (
  SELECT party_id, item_class_cd, COUNT(DISTINCT (tran_start_dt)) AS visitas,
    SUM(monto) as monto_total, SUM(unid) as unid_total,
    MAX(tran_start_dt) as ult_compra
  FROM fuente_filtrada
  GROUP BY party_id, item_class_cd
),

metricas as (
select party_id, item_class_cd, visitas, monto_total,
  round(unid_total) as unid_total,
  date_diff('day',ult_compra,NOW()) as rec
from subclasepop
)

SELECT a.party_id, a.item_class_cd,
  a.visitas / b.visitasprom AS lift_visitas,
  a.monto_total / b.monto_totalprom AS lift_mto,
  a.unid_total / b.unid_totalprom AS  lift_unid,
  a.rec / b.recprom AS  lift_rec
FROM metricas as a
LEFT JOIN (
  SELECT item_class_cd,
    AVG(visitas) AS visitasprom,
    AVG(monto_total) AS monto_totalprom,
    AVG(unid_total) AS unid_totalprom,
    AVG(rec) AS recprom
  FROM metricas
  GROUP BY 1
) AS b
ON a.item_class_cd = b.item_class_cd
