with items as (
  SELECT distinct
    prod_hier, id_com, id_oferta, celda as id_celda, id_dinamica,
    afinidad, prioridad, id_objetivo, corte_lift
  FROM PROD_HIER
  inner JOIN OFERTAS
  on PROD_HIER.parent_prod_hier = ofertas.cod_jer
  where id_com = {id_com}
  order by prod_hier
),

item_corr_dis as (
  select distinct prod_hier, corr
  from item_corr
),

corr as (
  select distinct
    a.prod_hier as item_id, cast(b.corr as varchar) as parent_prod_hier,
    99 as lvl, a.id_com, a.id_oferta, a.id_celda, a.id_dinamica,
    a.afinidad, a.prioridad, a.id_objetivo, a.corte_lift
  from items as a
  inner join item_corr_dis as b
  on a.prod_hier=b.prod_hier
),

ofe as (
  select distinct
    a.prod_hier as item_id, b.parent_prod_hier, b.parent_prod_lvl as lvl,
    a.id_com, a.id_oferta, a.id_celda, a.id_dinamica, a.afinidad,
    a.prioridad, a.id_objetivo, a.corte_lift
  from items as a
  left join prod_hier as b
  on a.prod_hier=b.prod_hier
  union
  select *
  from corr
)

select a.*, b.nombre, b.nivel, b.configuracion, b.regla, b.li, b.ls
from ofe a
inner join configuracion b
on a.id_dinamica = b.id_dinamica and a.lvl = b.lvl
