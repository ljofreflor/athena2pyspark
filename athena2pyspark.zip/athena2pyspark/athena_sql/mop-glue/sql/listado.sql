WITH ofertas_distinct as (
  select distinct
    canal, cod_siebel, id_com,
    id_oferta
  from ofertas
  where id_com = {id_com}
)

SELECT
  a.party_id,
  a.id_oferta as promo_id,
  b.canal as comm_channel_cd,
  b.cod_siebel as codigo_siebel,
  {id_com} as codigo_motor,
  a.id_com as communication_id,
  a.id_celda as page_id,
  CASE
    WHEN  c.nec_end_email <> '' THEN c.nec_end_email
    ELSE c.{flag}_cl_ind_email
  END AS datos_de_contacto,
  a.id_oferta as correlativo, (
    case
    when rand() <= 0.05 then 2
    else 0
    end
  ) as grupo
FROM clientes as c, priorizacion as a, ofertas_distinct as b
WHERE b.id_com = {id_com}
  and a.id_com = {id_com}
  AND a.party_id = c.party_id
  AND a.id_oferta = b.id_oferta
