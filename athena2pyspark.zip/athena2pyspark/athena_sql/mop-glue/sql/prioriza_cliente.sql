-- prioriza_cliente
with fuente_filtrada1 AS (
  SELECT PARTY_ID, tran_start_dt, MONTO_NETO,
        (
          CASE
            WHEN cast(WEIGHTED_AVERAGE_COST_AMT AS double) < 0 THEN 0
            ELSE cast(WEIGHTED_AVERAGE_COST_AMT AS double)
          END
        ) AS WEIGHTED_AVERAGE_COST_AMT
  FROM fuente
  WHERE cast(party_id AS integer)>0
    AND cast(MONTO_NETO AS double)>0
)
,

fuente_filtrada AS (
  SELECT PARTY_ID, tran_start_dt,
    sum(cast(MONTO_NETO AS double)) AS monto,
    sum(cast(WEIGHTED_AVERAGE_COST_AMT AS double)) AS costo
  FROM fuente_filtrada1
  WHERE cast(party_id AS integer)>0
    AND cast(MONTO_NETO AS double)>0
  GROUP BY 1,2
)
,

met_clientes AS (
  SELECT party_id, month(cast(tran_start_dt AS date)) AS mes,
    count(*) AS visitas, sum(monto) AS monto,
    sum(monto)-sum(costo) AS margen
  FROM fuente_filtrada
  GROUP BY 1,2
)
,

met_pop AS (
  SELECT mes, avg(visitas) AS visitasprom,
    avg(monto) AS montoprom,
    avg(margen) AS margenprom
  FROM met_clientes
  GROUP BY 1
)
,

lift AS (
  SELECT a.party_id, b.mes,
    a.visitas/b.visitasprom AS lift_visitas,
    a.monto/b.montoprom AS lift_monto,
    a.margen/b.margenprom AS lift_cont
  FROM met_clientes AS a
  LEFT JOIN met_pop AS b
  ON a.mes=b.mes
)
,

union_lift as (
  select party_id, mes, lift_visitas as lift, 1 as id_lift, 'visitas' as tipo_lift from lift
  union all
  select party_id, mes, lift_monto as lift, 2 as id_lift, 'monto' as tipo_lift from lift
  union all
  select party_id, mes, lift_cont as lift, 3 as id_lift, 'margen' as tipo_lift from lift
)

select * from union_lift

-- 	61768935 (Run time: 1 minutes 30 seconds, Data scanned: 60.28GB)
