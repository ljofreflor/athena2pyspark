-- prepri_objetivo_item
with channel as (
	select distinct party_id, (
		case
		when canal = 1 then cast({fl}_pos as varchar)
		when canal = 2 then cast({fl}_mail as varchar)
		else ''
		end
	) as filtro_canal
	from clientes, (
		select distinct canal
		from ofertas
		where id_com = {id_com}
	)
),

templ_aux as (
	select distinct a.party_id
	from template as a
	left join channel as b
	on a.party_id = b.party_id
	where id_com = {id_com}
		and filtro_canal = '1'
),

pcli as (
	select party_id, lift, ROW_NUMBER() OVER (
			ORDER BY lift DESC
		) AS lift_rank
	from prioriza_cliente
	where id_lift in (
		select distinct id_objetivo
		from ofertas
		where id_com = {id_com}
	) and party_id in (
		select party_id
		from templ_aux
	) and mes = (
		case
		when day(current_date) > 24 then month(current_date)+1
		when ((month(current_date)%2 = 0 and month(current_date) <= 7) or (month(current_date)%2 != 0 and month(current_date) > 7)) and day(current_date) > 23 then month(current_date)+1
		when month(current_date) = 2 and year(current_date)%4 != 0 and day(current_date) > 22 then month(current_date)+1
		when month(current_date) = 2 and year(current_date)%4 = 0 and day(current_date) > 21 then month(current_date)+1
		else month(current_date)
		end
	)
),

templ as (
	select distinct party_id
	from pcli
	where lift_rank <= (
		select distinct
			case
				when max_clientes = 0 then 99999999
				else max_clientes
			end as max_clientes
		from OFERTAS
		where max_clientes is not null and id_com = {id_com}
	)
),

mc as (
	select distinct cast(party_id as integer) as party_id,
		cast(cod_marca as integer) as cod_marca,
		cast(valor as integer) as valor
	from marca_clientes
	where cast(party_id as integer) in (
		select party_id
		from templ
	) and cast(cod_marca as integer) in (
		select distinct afinidad
		from matriz_de_configuracion
		where id_com = {id_com}
	)
),

obit_matconf as (
	select *, (
		case when li is null then 0
		else li
		end
	) as li_r, (
		case when ls is null then 9999999
		else ls
		end
	) as ls_r
	from matriz_de_configuracion
	where configuracion = 'objetivo_item'
		and id_com = {id_com}
),

obit_filtrada as (
	SELECT distinct item_id, lift_mto, lift_margen, lift_clientes
	FROM objetivo_item
	where mes = (
		case
		when day(current_date) > 24 then month(current_date)+1
		when ((month(current_date)%2 = 0 and month(current_date) <= 7) or (month(current_date)%2 != 0 and month(current_date) > 7)) and day(current_date) > 23 then month(current_date)+1
		when month(current_date) = 2 and year(current_date)%4 != 0 and day(current_date) > 22 then month(current_date)+1
		when month(current_date) = 2 and year(current_date)%4 = 0 and day(current_date) > 21 then month(current_date)+1
		else month(current_date)
		end
	) and item_id in  (
		select distinct item_id
		from obit_matconf
	)
),

obit_score as (
	select distinct b.id_celda, b.id_oferta, b.nivel, (
			case b.id_dinamica
			when 1 then lift_clientes
			when 2 then lift_mto
			when 3 then lift_margen
			end
		) as score, b.afinidad
	from obit_filtrada as a
	inner join obit_matconf as b
	on a.item_id = b.item_id
	where (
		case b.id_dinamica
		when 1 then lift_clientes
		when 2 then lift_mto
		when 3 then lift_margen
		end
	) > li_r
	and (
		case b.id_dinamica
		when 1 then lift_clientes
		when 2 then lift_mto
		when 3 then lift_margen
		end
	) < ls_r
),

obit_rank1 as (
	select *, RANK() OVER (
			PARTITION BY id_celda, id_oferta
			ORDER BY score DESC
		) AS rank_oferta
	from obit_score
),

obit_rank2 as (
	select *
	from templ, obit_rank1
	where rank_oferta = 1
),

obit_rank3 as (
	select a.*
	from obit_rank2 as a
	left join mc as b
	on a.afinidad = b.cod_marca and a.party_id = b.party_id
	where rank_oferta = 1
		and (a.afinidad = b.cod_marca or a.afinidad is null)
),

obit_rank4 as (
	select *, RANK() OVER (
			PARTITION BY party_id, id_celda
			ORDER BY score DESC
		) AS rank_celda
	from
		obit_rank3
)

select distinct party_id, id_celda, id_oferta, nivel, score, rank_celda, {id_com} as id_com
from obit_rank4
where rank_celda <= {ncelda}
