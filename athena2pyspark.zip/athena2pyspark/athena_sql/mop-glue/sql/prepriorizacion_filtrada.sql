-- prepriorizacion_filtrada
with union_metricas as (
  select *
  from prepri_consumo_habitual
  where id_com = {id_com}
  union all
	select *
  from prepri_propension
  where id_com = {id_com}
  union all
  select *
  from prepri_ciclo_recompra
  where id_com = {id_com}
  union all
  select *
  from prepri_party_subrubro
  where id_com = {id_com}
  union all
  select *
  from prepri_party_rubro
  where id_com = {id_com}
  union all
  select *
  from prepri_objetivo_item
  where id_com = {id_com}
),

union_rank as (
  select party_id, id_celda, id_oferta, nivel, score, 0 as score_real,
    score/(SUM(score) OVER (PARTITION BY party_id, id_celda)) as weight_oferta,
    row_number() over (
    	partition by party_id, id_celda, id_oferta
    	order by nivel
    ) as rank_nivel
  from union_metricas
),

union_rank2 as (
	select party_id as col0, id_celda as col1, id_oferta as col2, nivel as col3,
	    ROW_NUMBER() OVER (
	    	PARTITION BY party_id
	    	ORDER BY nivel ASC, score DESC, score_real DESC,
	    		weight_oferta DESC, id_celda ASC, id_oferta ASC
	    ) AS g_ranking,
		ROW_NUMBER() OVER (
			PARTITION BY party_id, id_oferta
			ORDER BY nivel ASC, score DESC, score_real DESC,
				weight_oferta DESC, id_celda ASC
		) AS c_ranking,
	    ROW_NUMBER() OVER (
	    	PARTITION BY party_id, id_celda
	    	ORDER BY nivel ASC, score DESC, score_real DESC,
	    		weight_oferta DESC, id_oferta ASC
	    ) AS o_ranking
	from union_rank
	where rank_nivel = 1
)

select *
from union_rank2
where o_ranking <= {ncelda}
order by col0, col2, col1
