-- proporcion por marca
with prob1 as (
	select distinct b.brand_cd, count(distinct a.party_id) as n_party
	from
		fuente as a,
		item_hash as b
  where cast(a.party_id as integer) > 0 and a.item_id is not null and a.item_id = b.item_id
  group by b.brand_cd
  order by b.brand_cd
)
,

prob2 as (
	select brand_cd, cast(n_party as double)/cast(total_party as double) as prob
	from prob1, (
  		select sum(n_party) as total_party from prob1
  	)
)

select * from prob2 order by brand_cd