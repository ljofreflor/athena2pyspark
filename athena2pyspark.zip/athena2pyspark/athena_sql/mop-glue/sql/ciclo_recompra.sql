with parties as (
	select distinct party_id
	from clientes
),

lp as (
	select a.party_id, a.corr, (
			case
			when a.ciclo_recompra = 0 then 0
			else 1/a.ciclo_recompra
			end
		) as CR
	from baul_lp as a
	join parties as b
	on cast(a.party_id as integer) = b.party_id
),

lpcorrpg as (
	select party_id, corr, max(CR) as CICLO_RECOMPRA
	from lp
	group by party_id, corr
),

lpcorrpop as (
	select corr, avg(CICLO_RECOMPRA) as PROM_CR
	from lpcorrpg
   group by corr
)

select party_id, a.CICLO_RECOMPRA/b.PROM_CR as lift_CR, b.corr as corr
from lpcorrpg as a
left join lpcorrpop as b
on a.corr = b.corr
