-- objetivo_item
WITH fuente_obj AS (
  SELECT party_id, item_id,
    month(cast(tran_start_dt as date)) as mes,
    cast(monto_neto as double) as monto,
    case
      when cast(monto_neto as double) - cast(WEIGHTED_AVERAGE_COST_AMT as double) <0 then 0
      else cast(monto_neto as double) - cast(WEIGHTED_AVERAGE_COST_AMT as double)
    end as margen
  from fuente
  where cast(party_id as integer) > 0
    and cast(monto_neto as double) > 0
    and cast(WEIGHTED_AVERAGE_COST_AMT as double) > 0
),

metricas_item as (
  select item_id, mes,
    sum(monto) as monto_tot,
    sum(margen) as margen_tot,
    count(distinct party_id) as clientes
  from fuente_obj
  group by item_id, mes
),

promedios as (
  select mes, avg(monto_tot) as monto_prom,
    avg(margen_tot) as margen_prom,
    avg(clientes) as clientes_prom
  from metricas_item
  group by mes
)

select a.item_id, a.mes,
  a.monto_tot/b.monto_prom as lift_mto,
  a.margen_tot/b.margen_prom as lift_margen,
  a.clientes/b.clientes_prom as lift_clientes
from metricas_item as a
left join promedios as b
on a.mes = b.mes
order by lift_margen desc
