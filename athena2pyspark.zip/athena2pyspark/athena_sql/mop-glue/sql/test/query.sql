select (*) from baul_2
