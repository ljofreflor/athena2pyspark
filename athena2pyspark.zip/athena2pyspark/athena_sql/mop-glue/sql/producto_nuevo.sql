-- athena2pyspark: producto nuevo
WITH seleccionador_de_ofertas as
(
  with items as
(SELECT distinct prod_hier, id_com, id_oferta, celda as id_celda, id_dinamica, afinidad, prioridad, id_objetivo, corte_lift
FROM PROD_HIER inner JOIN OFERTAS on PROD_HIER.parent_prod_hier =ofertas.cod_jer
where id_com={id_com})
,

item_corr_dis as
(select distinct prod_hier, corr from item_corr )


,
corr
as
(

select a.* ,  b.corr from items as a inner  join item_corr_dis as b on a.prod_hier=b.prod_hier)



select a.prod_hier as item_id,	a.id_com,	a.id_oferta,
       a.id_celda,	a.id_dinamica,	a.afinidad,
       a.prioridad,	a.id_objetivo,	a.corte_lift,
       b.item_subclass_cd,  b.item_class_cd, b.section_cd,
       b.brand_cd , a.corr 
from corr as a left join item_hash as b
on a.prod_hier=b.item_id
  )
  

,
sel_subclase as
(
  with sel_of_subclase as
  (select distinct id_oferta, id_celda, item_subclass_cd from seleccionador_de_ofertas where id_com={id_com})
select a.party_id, a.lift_visitas as lift_subclase, b.id_oferta, b.id_celda from afinidad_subclase as a
  inner join sel_of_subclase as b
  on a.item_subclass_cd=cast(b.item_subclass_cd as integer)
)

  
 -- select count(*) from sel_subclase 40 055 341
,
sel_marca as
(
  with sel_of_marca as
  (select distinct id_oferta, id_celda, brand_cd from seleccionador_de_ofertas where id_com={id_com})
select a.party_id, a.lift_visitas as lift_marca, b.id_oferta, b.id_celda from afinidad_marca as a
  inner join sel_of_marca as b
  on a.brand_cd=b.brand_cd
)

-- select count(*) from sel_marca  45 366 745

,
 -- select count(*) from sel_marca --     	21 079 519
 -- select count(*) from afinidad_marca --    270 935 956

lift
as (
SELECT a.party_id,
  a.id_oferta,
  a.id_celda,
       a.lift_subclase,
       b.lift_marca,
       a.lift_subclase*b.lift_marca AS lift_afinidad
FROM sel_subclase as a
  JOIN sel_marca as b ON a.party_id = b.party_id and a.id_oferta = b.id_oferta and a.id_celda = b.id_celda
  order by 6 desc)


 -- select count(*) from lift -- 114 817 878	Run time: 2 minutes 29 seconds, Data scanned: 4.6GB

,
contact as
(
  select party_id from template where id_com={id_com}
  )

  ,
  listado as
  (

select a.*, {id_com} as id_com from lift as a left join contact as b on
    a.party_id=b.party_id  where b.party_id is not null
  )
  
  select * from listado