-- prepriorizacion
with matriz_de_configuracion as (
	with items as (
    SELECT distinct
    	prod_hier, id_com, id_oferta, celda as id_celda, id_dinamica,
      afinidad, prioridad, id_objetivo, corte_lift
    FROM PROD_HIER
    inner JOIN OFERTAS
    on PROD_HIER.parent_prod_hier = ofertas.cod_jer
    where id_com = {id_com}
    order by prod_hier
  ),

  item_corr_dis as (
    select distinct prod_hier, corr
    from item_corr
  ),

  corr as (
		select distinct
			a.prod_hier as item_id, cast(b.corr as varchar) as parent_prod_hier,
	   	99 as lvl, a.id_com, a.id_oferta, a.id_celda, a.id_dinamica,
			a.afinidad, a.prioridad, a.id_objetivo, a.corte_lift
		from items as a
		inner join item_corr_dis as b
		on a.prod_hier=b.prod_hier
	),

	ofe as (
		select distinct
			a.prod_hier as item_id, b.parent_prod_hier, b.parent_prod_lvl as lvl,
			a.id_com, a.id_oferta, a.id_celda, a.id_dinamica, a.afinidad,
			a.prioridad, a.id_objetivo, a.corte_lift
		from items as a
		left join prod_hier as b
		on a.prod_hier=b.prod_hier
		union
		select *
		from corr
	)

	select a.*, b.nombre, b.nivel, b.configuracion, b.regla, b.li, b.ls
	from ofe a
	inner join configuracion b
	on a.id_dinamica = b.id_dinamica and a.lvl = b.lvl
),

channel as (
	select distinct party_id, (
		case
		when canal = 1 then cast({fl}_pos as varchar)
		when canal = 2 then cast({fl}_mail as varchar)
		else ''
		end
	) as filtro_canal
	from clientes, (
		select distinct canal
		from ofertas
		where id_com = {id_com}
	)
),

templ_aux as (
	select distinct a.party_id
	from template as a
	left join channel as b
	on a.party_id = b.party_id
	where id_com = {id_com}
		and filtro_canal = '1'
),

pcli as (
	select party_id, lift, ROW_NUMBER() OVER (
			ORDER BY lift DESC
		) AS lift_rank
	from prioriza_cliente
	where id_lift in (
		select distinct id_objetivo
		from ofertas
		where id_com = {id_com}
	) and party_id in (
		select party_id
		from templ_aux
	) and mes = (
		case
		when day(current_date) > 24 then month(current_date)+1
		when ((month(current_date)%2 = 0 and month(current_date) <= 7) or (month(current_date)%2 != 0 and month(current_date) > 7)) and day(current_date) > 23 then month(current_date)+1
		when month(current_date) = 2 and year(current_date)%4 != 0 and day(current_date) > 22 then month(current_date)+1
		when month(current_date) = 2 and year(current_date)%4 = 0 and day(current_date) > 21 then month(current_date)+1
		else month(current_date)
		end
	)
),

templ as (
	select distinct party_id
	from pcli
	where lift_rank <= (
		select distinct
			case
				when max_clientes = 0 then 99999999
				else max_clientes
			end as max_clientes
		from OFERTAS
		where max_clientes is not null and id_com = {id_com}
	)
),

mc as (
	select distinct cast(party_id as integer) as party_id, cod_marca,
		cast(valor as integer) as valor
	from marca_clientes
	where cast(party_id as integer) in (
		select party_id
		from templ
	) and cod_marca in (
		select distinct afinidad
		from matriz_de_configuracion
	)
),

prepri_producto_nuevo as (
	with pronu_matconf as (
		select a.*, (
				case when li is null then 0
				else li
				end
			) as li_r, (
				case when ls is null then 9999999
				else ls
				end
			) as ls_r,
	  	b.brand_cd
		from matriz_de_configuracion as a
	  inner join (
			select distinct item_id, brand_cd
			from item_hash
		) as b
		on a.item_id = b.item_id
		where configuracion = 'afinidad'
	),

	afma_filtrada as (
		select *
		from afinidad_marca
		where cast(brand_cd as varchar) in (
			select distinct brand_cd
			from pronu_matconf
		) and party_id in (
			select party_id
			from templ
		)
	),

	afsc_filtrada as (
		select *
		from afinidad_subclase
		where cast(item_subclass_cd as varchar) in (
			select distinct parent_prod_hier
			from pronu_matconf
		) and party_id in (
			select party_id
			from templ
		)
	),

	pronu_score as (
		select distinct b.party_id, a.id_celda, a.id_oferta, a.nivel, (
				case a.id_dinamica
				when 1 then b.lift_visitas*c.lift_visitas
				when 2 then b.lift_mto*c.lift_mto
				when 3 then b.lift_rec*c.lift_rec
				end
			) as score, a.afinidad
		from afsc_filtrada as b, afma_filtrada as c, pronu_matconf as a
		where (
			case a.id_dinamica
			when 1 then b.lift_visitas*c.lift_visitas
			when 2 then b.lift_mto*c.lift_mto
			when 3 then b.lift_rec*c.lift_rec
			end
		) > li_r
			and (
				case a.id_dinamica
				when 1 then b.lift_visitas*c.lift_visitas
				when 2 then b.lift_mto*c.lift_mto
				when 3 then b.lift_rec*c.lift_rec
				end
			) < ls_r
			and a.parent_prod_hier = cast(b.item_subclass_cd as VARCHAR)
			and a.brand_cd = cast(c.brand_cd as VARCHAR)
			and b.party_id = c.party_id
	),

	pronu_rank1 as (
		select *, rank() over (
				partition by party_id, id_celda, id_oferta
				order by score desc
			) as rank_oferta
		from pronu_score
	),

	pronu_rank2 as (
		select a.*
		from  pronu_rank1 as a
		left join mc as b
		on a.afinidad = b.cod_marca and a.party_id = b.party_id
		where rank_oferta = 1
			and (a.afinidad = b.cod_marca or a.afinidad is null)
	),

	pronu_rank3 as (
		select *, RANK() OVER (
				PARTITION BY party_id, id_celda
				ORDER BY score DESC
			) AS rank_celda
		from pronu_rank2
	)

	select party_id, id_celda, id_oferta, nivel, score, rank_celda, 'producto_nuevo' as metrica
	from pronu_rank3
	where rank_celda <= {ncelda}
	order by party_id, id_celda, id_oferta, score desc
),

prepri_ciclo_recompra as (
	with cire_matconf as (
		select *, (
				case when li is null then 0
				else li
				end
			) as li_r, (
				case when ls is null then 9999999
				else ls
				end
			) as ls_r
		from matriz_de_configuracion
		where configuracion = 'ciclo_recom'
	),

	cire_filtrada as (
	  select *
	  from ciclo_recompra
	  where cast(corr as varchar) in (
			select distinct parent_prod_hier
			from cire_matconf
		) and party_id in (
			select party_id
			from templ
		)
	),

	cire_score as (
		select distinct b.party_id, a.id_celda, a.id_oferta, a.nivel,
			b.lift_cr as score, a.afinidad
		from cire_filtrada as b, cire_matconf as a
		where b.lift_cr > li_r and b.lift_cr < ls_r
			and a.parent_prod_hier = cast(b.corr as varchar)
	),

	cire_rank1 as (
		select *, rank() over (
				partition by party_id, id_celda, id_oferta
				order by score desc
			) as rank_oferta
		from cire_score
	),

	cire_rank2 as (
		select a.*
		from cire_rank1 as a
		left join mc as b
		on a.afinidad = b.cod_marca and a.party_id = b.party_id
		where rank_oferta = 1
			and (a.afinidad = b.cod_marca or a.afinidad is null)
	),

	cire_rank3 as (
		select *, RANK() OVER (
				PARTITION BY party_id, id_celda
				ORDER BY score DESC
			) AS rank_celda
		from cire_rank2
	)

	select distinct party_id, id_celda, id_oferta, nivel, score, rank_celda, 'ciclo_recompra' as metrica
	from cire_rank3
	where rank_celda <= {ncelda}
),

prepri_party_subrubro as (
	with psr_matconf as (
		select *, (
			case when li is null then 0
			else li
			end
		) as li_r, (
			case when ls is null then 9999999
			else ls
			end
		) as ls_r
		from matriz_de_configuracion
		where configuracion = 'party_subrubro'
	),

	psr_filtrada as (
	  select *
	  from party_subrubro
	  where cast(item_subclass_cd as varchar) in (
			select distinct parent_prod_hier
			from psr_matconf
		) and party_id in (
			select party_id
			from templ
		)
	),

	psr_score as (
		select distinct b.party_id, a.id_celda, a.id_oferta, a.nivel, (
			case a.id_dinamica
			when 1 then lift_visitas
			when 2 then lift_mto
			when 3 then lift_rec
			end
		) as score, a.afinidad
		from psr_filtrada as b, psr_matconf as a
		where (
			case a.id_dinamica
			when 1 then lift_visitas
			when 2 then lift_mto
			when 3 then lift_rec
			end
		) > li_r and (
			case a.id_dinamica
			when 1 then lift_visitas
			when 2 then lift_mto
			when 3 then lift_rec
			end
		) < ls_r
			and a.parent_prod_hier = cast(b.item_subclass_cd as varchar)
	),

	psr_rank1 as (
		select *, RANK() OVER (
				PARTITION BY party_id, id_celda, id_oferta
				ORDER BY score DESC
			) AS rank_oferta
		from psr_score
	),

	psr_rank2 as (
		select a.*
		from psr_rank1 as a
		left join mc as b
		on a.afinidad = b.cod_marca and a.party_id = b.party_id
		where rank_oferta = 1
			and (a.afinidad = b.cod_marca or a.afinidad is null)
	),

	psr_rank3 as (
		select *, RANK() OVER (
				PARTITION BY party_id, id_celda
				ORDER BY score DESC
			) AS rank_celda
		from psr_rank2
	)

	select distinct party_id, id_celda, id_oferta, nivel, score, rank_celda, 'party_subrubro' as metrica
	from psr_rank3
	where rank_celda <= {ncelda}
),

prepri_party_rubro as (
	with pru_matconf as (
		select *, (
			case when li is null then 0
			else li
			end
		) as li_r, (
			case when ls is null then 9999999
			else ls
			end
		) as ls_r
		from matriz_de_configuracion
		where configuracion = 'party_rubro'
	),

	pru_filtrada as (
	  select *
	  from party_rubro
	  where cast(item_class_cd as varchar) in (
			select distinct parent_prod_hier
			from pru_matconf
		) and party_id in (
			select party_id
			from templ
		)
	),

	pru_score as (
		select distinct b.party_id, a.id_celda, a.id_oferta, a.nivel, (
			case a.id_dinamica
			when 1 then lift_visitas
			when 2 then lift_mto
			when 3 then lift_rec
			end
		) as score, a.afinidad
		from pru_filtrada as b, pru_matconf as a
		where (
			case a.id_dinamica
			when 1 then lift_visitas
			when 2 then lift_mto
			when 3 then lift_rec
			end
		) > li_r and (
			case a.id_dinamica
			when 1 then lift_visitas
			when 2 then lift_mto
			when 3 then lift_rec
			end
		) < ls_r
			and a.parent_prod_hier = cast(b.item_class_cd as varchar)
	),

	pru_rank1 as (
		select *, RANK() OVER (
				PARTITION BY party_id, id_celda, id_oferta
				ORDER BY score DESC
			) AS rank_oferta
		from pru_score
	),

	pru_rank2 as (
		select a.*
		from pru_rank1 as a
		left join mc as b
		on a.afinidad = b.cod_marca and a.party_id = b.party_id
		where rank_oferta = 1
			and (a.afinidad = b.cod_marca or a.afinidad is null)
	),

	pru_rank3 as (
		select *, RANK() OVER (
				PARTITION BY party_id, id_celda
				ORDER BY score DESC
			) AS rank_celda
		from pru_rank2
	)

	select distinct party_id, id_celda, id_oferta, nivel, score, rank_celda, 'party_rubro' as metrica
	from pru_rank3
	where rank_celda <= {ncelda}
),

prepri_objetivo_item as (
	with obit_matconf as (
		select *, (
			case when li is null then 0
			else li
			end
		) as li_r, (
			case when ls is null then 9999999
			else ls
			end
		) as ls_r
		from matriz_de_configuracion
		where configuracion = 'objetivo_item'
	),

	obit_filtrada as (
		SELECT distinct item_id, lift_mto, lift_margen, lift_clientes
		FROM objetivo_item
		where mes = (
			case
			when day(current_date) > 24 then month(current_date)+1
			when ((month(current_date)%2 = 0 and month(current_date) <= 7) or (month(current_date)%2 != 0 and month(current_date) > 7)) and day(current_date) > 23 then month(current_date)+1
			when month(current_date) = 2 and year(current_date)%4 != 0 and day(current_date) > 22 then month(current_date)+1
			when month(current_date) = 2 and year(current_date)%4 = 0 and day(current_date) > 21 then month(current_date)+1
			else month(current_date)
			end
		) and item_id in  (
			select distinct item_id
			from obit_matconf
		)
	),

	obit_score as (
		select distinct b.id_celda, b.id_oferta, b.nivel, (
				case b.id_dinamica
    		when 1 then lift_clientes
    		when 2 then lift_mto
    		when 3 then lift_margen
    		end
			) as score, b.afinidad
		from obit_filtrada as a
		inner join obit_matconf as b
		on a.item_id = b.item_id
		where (
			case b.id_dinamica
			when 1 then lift_clientes
			when 2 then lift_mto
			when 3 then lift_margen
			end
		) > li_r
		and (
			case b.id_dinamica
			when 1 then lift_clientes
			when 2 then lift_mto
			when 3 then lift_margen
			end
		) < ls_r
	),

	obit_rank1 as (
		select *, RANK() OVER (
				PARTITION BY id_celda, id_oferta
				ORDER BY score DESC
			) AS rank_oferta
		from obit_score
	),

	obit_rank2 as (
		select *
		from templ, obit_rank1
		where rank_oferta = 1
	),

	obit_rank3 as (
		select a.*
		from obit_rank2 as a
		left join mc as b
		on a.afinidad = b.cod_marca and a.party_id = b.party_id
		where rank_oferta = 1
			and (a.afinidad = b.cod_marca or a.afinidad is null)
	),

	obit_rank4 as (
		select *, RANK() OVER (
				PARTITION BY party_id, id_celda
				ORDER BY score DESC
			) AS rank_celda
		from
			obit_rank3
	)

	select distinct party_id, id_celda, id_oferta, nivel, score, rank_celda, 'objetivo_item' as metrica
	from obit_rank4
	where rank_celda <= {ncelda}
)
,

prepri_propension as (
	with prop_matconf as (
		select *, (
			case when li is null then 0
			else li
			end
		) as li_r, (
			case when ls is null then 9999999
			else ls
			end
		) as ls_r
		from matriz_de_configuracion
		where configuracion = 'score'
	),

	prop_filtrada as (
	  select *
	  from propension
	  where cast(corr as varchar) in (
			select distinct parent_prod_hier
			from prop_matconf
		) and party_id in (
			select party_id
			from templ
		)
	),

	prop_score as (
		select distinct b.party_id, a.id_celda, a.id_oferta, a.nivel, b.score, a.afinidad
		from prop_filtrada as b, prop_matconf as a
		where b.score > li_r and b.score < ls_r
			and a.parent_prod_hier = cast(b.corr as varchar)
	),

	prop_rank1 as (
		select *, RANK() OVER (
				PARTITION BY party_id, id_celda, id_oferta
				ORDER BY score DESC
			) AS rank_oferta
		from prop_score
	),

	prop_rank2 as (
		select a.*
		from prop_rank1 as a
		left join mc as b
		on a.afinidad = b.cod_marca and a.party_id = b.party_id
		where rank_oferta = 1
			and (a.afinidad = b.cod_marca or a.afinidad is null)
	),

	prop_rank3 as (
		select *, RANK() OVER (
				PARTITION BY party_id, id_celda
				ORDER BY score DESC
			) AS rank_celda
		from prop_rank2
	)

	select distinct party_id, id_celda, id_oferta, nivel, score, rank_celda, 'score' as metrica
	from prop_rank3
	where rank_celda <= {ncelda}
),

union_metricas as (
  select * from prepri_producto_nuevo
  union all
	select * from prepri_propension
  union all
  select * from prepri_ciclo_recompra
  union all
  select * from prepri_party_subrubro
  union all
  select * from prepri_party_rubro
  union all
  select * from prepri_objetivo_item
),

union_rank as (
  select party_id, id_celda, id_oferta, nivel, score, 0 as score_real,
    score/(SUM(score) OVER (PARTITION BY party_id, id_celda)) as weight_oferta,
    row_number() over (
    	partition by party_id, id_celda, id_oferta
    	order by nivel
    ) as rank_nivel, metrica
  from union_metricas
),

union_rank2 as (
	select party_id as col0, id_celda as col1, id_oferta as col2, nivel as col3,
	    ROW_NUMBER() OVER (
	    	PARTITION BY party_id
	    	ORDER BY nivel ASC, score DESC, score_real DESC,
	    		weight_oferta DESC, id_celda ASC, id_oferta ASC
	    ) AS g_ranking,
		ROW_NUMBER() OVER (
			PARTITION BY party_id, id_oferta
			ORDER BY nivel ASC, score DESC, score_real DESC,
				weight_oferta DESC, id_celda ASC
		) AS c_ranking,
	    ROW_NUMBER() OVER (
	    	PARTITION BY party_id, id_celda
	    	ORDER BY nivel ASC, score DESC, score_real DESC,
	    		weight_oferta DESC, id_oferta ASC
	    ) AS o_ranking
	from union_rank
	where rank_nivel = 1
)

select *
from union_rank2
where o_ranking <= {ncelda}
order by col0, col2, col1
