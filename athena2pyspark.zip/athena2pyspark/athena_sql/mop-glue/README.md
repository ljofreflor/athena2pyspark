# README #

### What is this repository for? ###

* Repositorio codigos pyspark para AWS Glue
* beta/test

### How do I get set up? ###

* Summary of set up
* Configuration
* Dependencies
* Database configuration
* How to run tests
* Deployment instructions
