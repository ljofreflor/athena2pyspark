
from setuptools import setup

setup(
    name="athena2pyspark",
    version=0.1,
    scripts=["athena2pyspark"]
)

