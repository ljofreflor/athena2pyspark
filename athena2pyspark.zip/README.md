

ATHENA 2 PYSPARK

Esta librería contiene las funcionalidades para consumir athena desde pyspark


ejecutar una query


crear una tabla